package ejercicio03;

public class Operaciones {
	

	
	
	public Operaciones (int num) {

	}
	
	public boolean comprobarSigno (int num) {
		
		if (num>=0) {
			return true;
		}else {
		return false;	
		}
	
			}
}
